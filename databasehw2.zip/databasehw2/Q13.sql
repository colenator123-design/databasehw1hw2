/*  
Q13 
*/ 
select concat(`FNAME`, ' ', `LNAME`)
from `EMPLOYEE`
left join `DEPENDENT`
on `SSN` = `ESSN`
where `dependent_name` is null
;