/*  
Q6 
*/ 
select `ssn`, `dno`
from `employee`;