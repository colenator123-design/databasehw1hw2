/*  
Q26 
*/ 
select `DNAME`
from `DEPARTMENT`
join `employee`
on `DNO`=`DNUMBER`
group by `DNUMBER`
having sum(case when `salary` > 30000 then 1 else 0 end) > 2;