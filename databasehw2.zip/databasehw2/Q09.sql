/*  
Q9 
*/ 
select * from `EMPLOYEE` where `ADDRESS` like '%Houston TX';