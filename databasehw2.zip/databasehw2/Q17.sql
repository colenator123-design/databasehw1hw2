/*  
Q17 
*/ 
select  concat(`FNAME`,' ', `LNAME`)
from `EMPLOYEE` 
where `SALARY` > (select max(`SALARY`) from `EMPLOYEE` where `DNO` =5)  ;