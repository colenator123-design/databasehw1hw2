/*  
Q2 
*/ 
select `PNUMBER`, `DNUM`,`LNAME`,`ADDRESS`,`BDATE`
from `PROJECT`
join `DEPARTMENT`
on `DNUM` = `DNUMBER`
join `EMPLOYEE`
on `MGRSSN` = `SSN`
where `PLOCATION` = 'Stafford';
