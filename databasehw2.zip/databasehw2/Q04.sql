/*  
Q4 
*/ 
select `PNUMBER`
from `PROJECT`
join `works_on`
on `PNUMBER` = `PNO`
join `EMPLOYEE`
on `ESSN` = `SSN`
where `LNAME` = 'wong';