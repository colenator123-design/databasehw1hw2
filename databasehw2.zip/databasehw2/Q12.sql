/*  
Q12 
*/ 
select concat(`fname`, ' ', `lname`)
from `employee`
join `dependent`
on `ssn` = `essn`
where `fname` = `dependent_name` and `employee`.`sex` = `dependent`.`sex`;

