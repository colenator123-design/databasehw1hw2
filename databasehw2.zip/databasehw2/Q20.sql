/*  
Q20 
*/ 
select count(*)
from `DEPARTMENT`
join `EMPLOYEE`
on `DNUMBER` = `DNO`
where `DNAME` = 'Research';
