/*  
Q19 
*/ 
select sum(`SALARY`), max(`SALARY`), min(`SALARY`), avg(`SALARY`)
from `DEPARTMENT`
join `EMPLOYEE`
on `DNUMBER` = `DNO`
where `DNAME` = 'Research';