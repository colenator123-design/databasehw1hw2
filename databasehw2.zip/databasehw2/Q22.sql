/*  
Q22 
*/ 
select `PNUMBER`, `PNAME` , COUNT(ESSN)
from  `project`
join `works_on`
on `PNO`= `PNUMBER`
group by `PNO`;
