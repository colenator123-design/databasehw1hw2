/*  
Q14 
*/ 
select distinct  concat(`fname`, ' ', `lname`)
from `department`
left join `employee`
on `mgrssn` = `ssn`
join `dependent`
on `mgrssn` = `essn`;