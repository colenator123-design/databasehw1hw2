/*  
Q15 
*/ 
select distinct  concat(`fname`, ' ', `lname`)
from `department`
left join `employee`
on `mgrssn` = `ssn`
join `dependent`
on `mgrssn` = `essn`
group by   concat(`fname`, ' ', `lname`)
having count(*) >1
;