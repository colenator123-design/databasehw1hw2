/*  
Q27 
*/ 
select concat(`FNAME`, `LNAME`) 
from `project`
join `works_on`
on `PNUMBER` = `PNO`
join `employee`
on `ESSN` = `SSN`
where `DNUM` = 5
group by `SSN`
having count(distinct `PNO`) = 3
;
