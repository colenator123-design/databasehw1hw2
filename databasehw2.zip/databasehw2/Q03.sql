/*  
Q3 
*/ 
select distinct concat(`FNAME`,' ', `LNAME`)
from `PROJECT`
join `works_on`
on `PNUMBER` = `PNO`
join `EMPLOYEE`
on `ESSN` = `SSN`
where `DNUM` = 5;