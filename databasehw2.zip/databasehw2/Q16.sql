/*  
Q16 
*/ 
select distinct `SSN`
from `works_on`
join `EMPLOYEE`
on `SSN` = `ESSN`
where `pno` in(select `pno` from `works_on` where `essn`= '123456789');