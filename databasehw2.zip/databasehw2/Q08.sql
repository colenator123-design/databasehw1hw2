/*  
Q8 
*/ 
select distinct `SALARY` from `EMPLOYEE` ;