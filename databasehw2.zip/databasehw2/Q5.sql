/*  
Q5 
*/ 
select `fname`,`lname`, (select `fname` from `employee` as o where `employee`.`superssn` = `o`.`ssn`), (select `lname` from `employee` as m where `employee`.`superssn` = `m`.`ssn`)
from `employee`
;