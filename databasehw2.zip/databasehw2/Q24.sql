/*  
Q24 
*/ 
select `PNUMBER`, `PNAME` , sum(case when `DNO` = 5 then 1 else 0  end)
from  
(`project`
left join `works_on`
on `PNO`= `PNUMBER`)
join `employee`
on `ESSN` = `SSN`
group by `PNO`;



