/*  
Q11 
*/ 
select * 
from `employee`
join `department`
on `dno` = `dnumber`
order by `dname` desc ,`fname`,`lname` asc;