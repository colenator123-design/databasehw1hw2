/*  
Q10 
*/ 
select `SALARY`*1.15 from `EMPLOYEE`;