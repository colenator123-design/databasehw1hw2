/*  
Q25 
*/ 
select `DNUMBER`, sum(case when `salary` > 30000 then 1 else 0 end)
from `DEPARTMENT`
join `employee`
on `DNO`=`DNUMBER`
group by `DNUMBER`
having count(*) > 2;

