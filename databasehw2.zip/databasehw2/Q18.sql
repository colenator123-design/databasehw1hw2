/*  
Q18 
*/ 
select sum(`SALARY`), max(`SALARY`), min(`SALARY`), avg(`SALARY`)
from `EMPLOYEE`;