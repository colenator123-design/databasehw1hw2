/*  
Q7 
*/ 
select `SSN`, `DNAME`
from `EMPLOYEE`
join `DEPARTMENT`
on `DNO` = `DNUMBER`;